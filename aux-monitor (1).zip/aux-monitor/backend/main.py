import random
import time
from contextlib import asynccontextmanager
from datetime import date, timedelta

from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import distinct, func
from sqlalchemy.orm import Session

from database import Base, SessionLocal, engine, get_db
from models import AuxDeviationOutput as O
from seed import seed_if_empty
from services import IS_LLM, NORMS, rebuild_output


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)          # tables are created automatically
    with SessionLocal() as db:
        seed_if_empty(db)                          # dummy data
        if db.query(O).count() == 0:
            rebuild_output(db, use_llm=IS_LLM)     # deviation + explanation table
    yield


app = FastAPI(title="AUX Monitor API", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


def since(days: int):
    return O.work_date >= date.today() - timedelta(days=days)


def n(x, d=1):
    return round(float(x or 0), d)


@app.get("/api/config")
def config():
    return {"norms": NORMS, "threshold_min": 540, "is_llm": IS_LLM}


@app.get("/api/kpis")
def kpis(days: int = 14, db: Session = Depends(get_db)):
    r = db.query(
        func.count(distinct(O.user_name)), func.avg(O.working_time_min), func.avg(O.compliance_pct),
        func.sum(O.total_excess_min), func.sum(O.per_excess_min), func.avg(O.utilization_pct),
        func.sum(O.shortfall_min),
    ).filter(since(days)).one()
    high = db.query(func.count()).filter(since(days), O.severity.in_(["High", "Critical"])).scalar()
    return {
        "agents": r[0], "avg_working_min": n(r[1]), "avg_compliance": n(r[2]),
        "leakage_min": n(r[3], 0), "per_excess_min": n(r[4], 0), "avg_utilization": n(r[5]),
        "shortfall_min": n(r[6], 0), "high_risk_cases": high,
    }


@app.get("/api/trend")
def trend(days: int = 14, db: Session = Depends(get_db)):
    rows = db.query(
        O.work_date, func.avg(O.working_time_min), func.avg(O.threshold_min),
        func.avg(O.total_excess_min), func.avg(O.acw_min), func.avg(O.per_min), func.avg(O.cbk_min),
    ).filter(since(days)).group_by(O.work_date).order_by(O.work_date).all()
    return [{"date": r[0].isoformat(), "avg_working_min": n(r[1]), "threshold_min": n(r[2]),
             "avg_leakage_min": n(r[3]), "avg_acw": n(r[4]), "avg_per": n(r[5]), "avg_cbk": n(r[6])}
            for r in rows]


@app.get("/api/breakdown")
def breakdown(days: int = 14, db: Session = Depends(get_db)):
    r = db.query(func.sum(O.productive_min), func.sum(O.acw_min), func.sum(O.per_min),
                 func.sum(O.cbk_min)).filter(since(days)).one()
    return {"productive": n(r[0], 0), "acw": n(r[1], 0), "per": n(r[2], 0), "cbk": n(r[3], 0)}


@app.get("/api/severity")
def severity(days: int = 14, db: Session = Depends(get_db)):
    rows = db.query(O.severity, func.count()).filter(since(days)).group_by(O.severity).all()
    return [{"severity": s, "count": c} for s, c in rows]


@app.get("/api/users")
def users(days: int = 14, db: Session = Depends(get_db)):
    rows = db.query(
        O.user_name, func.avg(O.working_time_min), func.avg(O.acw_min), func.avg(O.per_min),
        func.avg(O.cbk_min), func.sum(O.total_excess_min), func.avg(O.compliance_pct),
        func.avg(O.utilization_pct), func.avg(O.risk_score),
        func.count().filter(O.severity.in_(["High", "Critical"])),
        func.sum(O.acw_excess_min), func.sum(O.per_excess_min), func.sum(O.cbk_excess_min),
    ).filter(since(days)).group_by(O.user_name).order_by(func.sum(O.total_excess_min).desc()).all()
    return [{
        "user_name": r[0], "avg_working_min": n(r[1]), "avg_acw": n(r[2]), "avg_per": n(r[3]),
        "avg_cbk": n(r[4]), "leakage_min": n(r[5], 0), "compliance": n(r[6]), "utilization": n(r[7]),
        "avg_risk": n(r[8]), "high_risk_days": r[9], "acw_excess": n(r[10], 0),
        "per_excess": n(r[11], 0), "cbk_excess": n(r[12], 0),
    } for r in rows]


@app.get("/api/deviations")
def deviations(days: int = 30, severity: str | None = None, user: str | None = None,
               limit: int = 300, db: Session = Depends(get_db)):
    q = db.query(O).filter(since(days))
    if severity and severity != "All":
        q = q.filter(O.severity == severity)
    if user and user != "All":
        q = q.filter(O.user_name == user)
    rows = q.order_by(O.risk_score.desc(), O.work_date.desc()).limit(limit).all()
    out = []
    for r in rows:
        d = {c.name: getattr(r, c.name) for c in r.__table__.columns}
        d["work_date"] = d["work_date"].isoformat()
        d["created_at"] = d["created_at"].isoformat() if d["created_at"] else None
        out.append(d)
    return out


@app.post("/api/process")
def process(use_llm: bool = True, limit: int = 20, db: Session = Depends(get_db)):
    """Recompute the output table; optionally ask the LLM to explain the riskiest rows."""
    return rebuild_output(db, use_llm=use_llm, llm_limit=limit)


# ---------- simulated real-time feed ----------
LIVE_STATES = ["On Call", "Available", "ACW", "PER", "CBK"]
LIVE_WEIGHTS = [40, 25, 15, 12, 8]
LIVE_PER_ALERT_SEC = 60   # demo value; use 600+ in production
_live: dict = {}


@app.get("/api/live")
def live(db: Session = Depends(get_db)):
    names = [r[0] for r in db.query(distinct(O.user_name)).order_by(O.user_name).all()]
    now = time.time()
    out = []
    for name in names:
        cur = _live.get(name)
        change_p = 0.04 if cur and cur["state"] == "PER" else 0.15
        if cur is None or random.random() < change_p:
            cur = _live[name] = {"state": random.choices(LIVE_STATES, LIVE_WEIGHTS)[0], "since": now}
        secs = int(now - cur["since"])
        out.append({"user_name": name, "state": cur["state"], "seconds": secs,
                    "alert": cur["state"] == "PER" and secs >= LIVE_PER_ALERT_SEC})
    return {"timestamp": now, "per_alert_sec": LIVE_PER_ALERT_SEC, "agents": out}
