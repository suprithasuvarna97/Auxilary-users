import os
from concurrent.futures import ThreadPoolExecutor
import httpx
from models import AuxActivity, AuxDeviationOutput

# Allowed daily norms (minutes) for each auxiliary state
NORMS = {"acw": 60, "per": 45, "cbk": 30}
LLM_MODEL = os.getenv("LLM_MODEL", "claude-sonnet-5-5")
# Master switch: false -> never call the LLM, use dummy (rule-based) explanations
IS_LLM = os.getenv("IS_LLM", "false").strip().lower() in ("1", "true", "yes")


def fmt(minutes):
    h, m = divmod(int(minutes), 60)
    return f"{h}h {m:02d}m"


def compute(a: AuxActivity) -> dict:
    """Deviation maths for one agent-day."""
    acw_x = max(0, a.acw_min - NORMS["acw"])
    per_x = max(0, a.per_min - NORMS["per"])
    cbk_x = max(0, a.cbk_min - NORMS["cbk"])
    total_x = acw_x + per_x + cbk_x
    aux_total = a.acw_min + a.per_min + a.cbk_min
    productive = max(0, a.working_time_min - aux_total)
    shortfall = max(0, a.threshold_min - a.working_time_min)
    util = round(productive / a.working_time_min * 100, 1) if a.working_time_min else 0.0
    comp = round(a.working_time_min / a.threshold_min * 100, 1) if a.threshold_min else 0.0
    risk = round(total_x + 0.5 * shortfall, 1)
    severity = "Critical" if risk >= 90 else "High" if risk >= 60 else "Medium" if risk >= 30 else "Low"
    return dict(acw_x=acw_x, per_x=per_x, cbk_x=cbk_x, total_x=total_x, productive=productive,
                shortfall=shortfall, util=util, comp=comp, risk=risk, severity=severity)


def facts(a: AuxActivity, m: dict) -> dict:
    return dict(user=a.user_name, date=str(a.work_date), working=fmt(a.working_time_min),
                threshold=fmt(a.threshold_min), shortfall=m["shortfall"], acw=a.acw_min,
                per=a.per_min, cbk=a.cbk_min, acw_x=m["acw_x"], per_x=m["per_x"], cbk_x=m["cbk_x"],
                total_x=m["total_x"], util=m["util"], severity=m["severity"])


def rule_explain(f: dict) -> str:
    """Fallback explanation when no LLM key is configured."""
    if f["shortfall"] > 0:
        s1 = (f"{f['user']} was logged in for {f['working']} against a {f['threshold']} target, "
              f"leaving {f['shortfall']} min of paid capacity unused.")
    else:
        s1 = f"{f['user']} met the {f['threshold']} login target."
    drivers = []
    if f["per_x"]:
        drivers.append(f"personal/break time was {f['per']} min vs a {NORMS['per']} min norm (+{f['per_x']})")
    if f["acw_x"]:
        drivers.append(f"after-call work was {f['acw']} min vs {NORMS['acw']} (+{f['acw_x']})")
    if f["cbk_x"]:
        drivers.append(f"callback time was {f['cbk']} min vs {NORMS['cbk']} (+{f['cbk_x']})")
    s2 = ("Time leaked mainly because " + "; ".join(drivers) + "." if drivers
          else "All auxiliary states stayed inside their norms.")
    action = {
        "Critical": "Recommend an immediate coaching conversation and a review of break scheduling.",
        "High": "Recommend a team-lead check-in this week.",
        "Medium": "Keep monitoring; a gentle reminder on break discipline may be enough.",
        "Low": "No action needed.",
    }[f["severity"]]
    return f"{s1} {s2} {action}"


def llm_explain(f: dict):
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key:
        return None
    prompt = (
        "You are an operations analyst. Write a 2-3 sentence, business-friendly explanation "
        "(no jargon, no bullet points) of this call-centre agent's day, covering where time "
        "was lost and one recommended action. Aux codes: ACW=after-call work, PER=personal/"
        f"break time, CBK=callback. Norms (min): {NORMS}.\nFacts: {f}"
    )
    try:
        r = httpx.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": key, "anthropic-version": "2023-06-01",
                     "content-type": "application/json"},
            json={"model": LLM_MODEL, "max_tokens": 250,
                  "messages": [{"role": "user", "content": prompt}]},
            timeout=40,
        )
        r.raise_for_status()
        return r.json()["content"][0]["text"].strip()
    except Exception as exc:  # fall back silently to rules
        print("LLM call failed:", exc)
        return None


def rebuild_output(db, use_llm=False, llm_limit=20) -> dict:
    """Recompute the output table. LLM is used for the `llm_limit` riskiest rows."""
    use_llm = use_llm and IS_LLM
    db.query(AuxDeviationOutput).delete()
    pairs = [(a, compute(a)) for a in db.query(AuxActivity).all()]
    all_facts = {a.id: facts(a, m) for a, m in pairs}

    llm_text = {}
    if use_llm:
        worst = sorted(pairs, key=lambda p: -p[1]["risk"])[:llm_limit]
        with ThreadPoolExecutor(max_workers=5) as ex:
            futures = {a.id: ex.submit(llm_explain, all_facts[a.id]) for a, _ in worst}
            llm_text = {i: f.result() for i, f in futures.items()}

    llm_rows = 0
    for a, m in pairs:
        text_ = llm_text.get(a.id)
        source = "llm" if text_ else "rules"
        llm_rows += bool(text_)
        db.add(AuxDeviationOutput(
            activity_id=a.id, user_name=a.user_name, work_date=a.work_date,
            working_time_min=a.working_time_min, threshold_min=a.threshold_min,
            acw_min=a.acw_min, per_min=a.per_min, cbk_min=a.cbk_min,
            acw_excess_min=m["acw_x"], per_excess_min=m["per_x"], cbk_excess_min=m["cbk_x"],
            total_excess_min=m["total_x"], shortfall_min=m["shortfall"],
            productive_min=m["productive"], utilization_pct=m["util"], compliance_pct=m["comp"],
            risk_score=m["risk"], severity=m["severity"],
            llm_explanation=text_ or rule_explain(all_facts[a.id]), explanation_source=source,
        ))
    db.commit()
    return {"rows": len(pairs), "llm_rows": llm_rows, "is_llm": IS_LLM}
