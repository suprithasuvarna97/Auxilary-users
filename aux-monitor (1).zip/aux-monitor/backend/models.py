from datetime import datetime
from sqlalchemy import Column, Date, DateTime, Float, Integer, String, Text, UniqueConstraint
from database import Base


class AuxActivity(Base):
    """Raw input table: one row per agent per day. All durations are in minutes."""
    __tablename__ = "aux_activity"
    __table_args__ = (UniqueConstraint("user_name", "work_date"),)

    id = Column(Integer, primary_key=True)
    user_name = Column(String(80), nullable=False, index=True)
    work_date = Column(Date, nullable=False, index=True)
    working_time_min = Column(Integer, nullable=False)   # logged-in time per day
    acw_min = Column(Integer, nullable=False)            # After Call Work
    per_min = Column(Integer, nullable=False)            # Personal / break time
    cbk_min = Column(Integer, nullable=False)            # Callback
    threshold_min = Column(Integer, nullable=False, default=540)  # 9 hours


class AuxDeviationOutput(Base):
    """Output table: calculated deviations + business friendly LLM explanation."""
    __tablename__ = "aux_deviation_output"

    id = Column(Integer, primary_key=True)
    activity_id = Column(Integer, index=True)
    user_name = Column(String(80), index=True)
    work_date = Column(Date, index=True)
    working_time_min = Column(Integer)
    threshold_min = Column(Integer)
    acw_min = Column(Integer)
    per_min = Column(Integer)
    cbk_min = Column(Integer)
    acw_excess_min = Column(Integer)
    per_excess_min = Column(Integer)
    cbk_excess_min = Column(Integer)
    total_excess_min = Column(Integer)     # time leaked beyond the allowed norms
    shortfall_min = Column(Integer)        # threshold - working time (if below)
    productive_min = Column(Integer)       # working time - all aux time
    utilization_pct = Column(Float)
    compliance_pct = Column(Float)
    risk_score = Column(Float)
    severity = Column(String(10), index=True)
    llm_explanation = Column(Text)
    explanation_source = Column(String(10))  # "llm" or "rules"
    created_at = Column(DateTime, default=datetime.utcnow)
