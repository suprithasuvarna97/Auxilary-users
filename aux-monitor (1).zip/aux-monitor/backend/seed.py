import random
from datetime import date, timedelta
from models import AuxActivity

USERS = [
    ("Aarav Sharma", "good"), ("Priya Nair", "good"), ("Rohan Mehta", "average"),
    ("Sneha Iyer", "average"), ("Karthik Reddy", "breaker"), ("Ananya Das", "average"),
    ("Vikram Singh", "breaker"), ("Meera Joshi", "acw_heavy"), ("Rahul Verma", "good"),
    ("Divya Menon", "erratic"), ("Arjun Patel", "acw_heavy"), ("Neha Gupta", "average"),
]
# profile -> (login shift vs threshold, avg ACW, avg PER, avg CBK) in minutes
PROFILES = {
    "good": (0, 50, 35, 22),
    "average": (-20, 62, 50, 30),
    "breaker": (-45, 70, 95, 35),
    "acw_heavy": (-25, 115, 45, 28),
    "erratic": (-30, 75, 70, 40),
}
THRESHOLD_MIN = 9 * 60


def seed_if_empty(db, days=30):
    if db.query(AuxActivity).count():
        return
    rnd = random.Random(42)
    for offset in range(days, 0, -1):
        day = date.today() - timedelta(days=offset)
        if day.weekday() >= 5:  # skip weekends
            continue
        for name, profile in USERS:
            shift, acw, per, cbk = PROFILES[profile]
            sd = 2.0 if profile == "erratic" else 1.0
            work = max(300, min(600, int(rnd.gauss(THRESHOLD_MIN + shift, 25 * sd))))
            db.add(AuxActivity(
                user_name=name, work_date=day, working_time_min=work,
                acw_min=max(5, int(rnd.gauss(acw, 14 * sd))),
                per_min=max(5, int(rnd.gauss(per, 14 * sd))),
                cbk_min=max(2, int(rnd.gauss(cbk, 8 * sd))),
                threshold_min=THRESHOLD_MIN,
            ))
    db.commit()
