export const COLORS = {
  productive: "#0F766E",
  acw: "#7C9BE0",
  per: "#F2765A",
  cbk: "#E7B24A",
  ink: "#10312F",
  grid: "#E3E9E6",
  muted: "#6B7F7C",
};
export const SEVERITY_COLORS = { Low: "#0F766E", Medium: "#E7B24A", High: "#F2765A", Critical: "#B42318" };
export const tooltipStyle = {
  contentStyle: { borderRadius: 8, border: "1px solid #DCE3E0", boxShadow: "none", fontSize: 12 },
  labelStyle: { fontWeight: 600, color: "#10312F" },
};
export const axisProps = { tick: { fontSize: 11, fill: "#6B7F7C" }, axisLine: false, tickLine: false };
