export default function Status({ loading, error }) {
  if (error)
    return (
      <div className="status error">
        Could not load data: {error}. Check that the API is running on port 8000.
      </div>
    );
  if (loading) return <div className="status">Loading data…</div>;
  return null;
}
