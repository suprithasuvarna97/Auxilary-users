import { Activity, AlertTriangle, LayoutDashboard, PieChart, Radio, Users } from "lucide-react";

const ITEMS = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "analysis", label: "Aux analysis", icon: PieChart },
  { id: "agents", label: "Agents", icon: Users },
  { id: "deviations", label: "Deviation report", icon: AlertTriangle },
  { id: "live", label: "Live monitor", icon: Radio },
];

export default function Sidebar({ page, onChange }) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <span className="brand-mark"><Activity size={18} /></span>
        <div>
          <strong>AUX Monitor</strong>
          <small>Time-leakage tracking</small>
        </div>
      </div>
      <nav>
        {ITEMS.map(({ id, label, icon: Icon }) => (
          <button key={id} className={page === id ? "nav active" : "nav"} onClick={() => onChange(id)}>
            <Icon size={17} />
            {label}
          </button>
        ))}
      </nav>
      <div className="side-note">
        <b>Aux codes</b>
        <span><i style={{ background: "#7C9BE0" }} />ACW · after-call work</span>
        <span><i style={{ background: "#F2765A" }} />PER · personal / break</span>
        <span><i style={{ background: "#E7B24A" }} />CBK · callback</span>
      </div>
    </aside>
  );
}
