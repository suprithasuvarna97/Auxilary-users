export default function KpiCard({ icon: Icon, label, value, unit, sub, tone = "teal" }) {
  return (
    <div className={`kpi tone-${tone}`}>
      <div className="kpi-icon"><Icon size={18} /></div>
      <div className="kpi-body">
        <span className="kpi-label">{label}</span>
        <span className="kpi-value">
          {value}
          {unit && <em>{unit}</em>}
        </span>
        {sub && <span className="kpi-sub">{sub}</span>}
      </div>
    </div>
  );
}
