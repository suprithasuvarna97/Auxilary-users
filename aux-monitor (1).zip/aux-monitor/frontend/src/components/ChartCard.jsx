export default function ChartCard({ title, hint, children, className = "" }) {
  return (
    <section className={`card ${className}`}>
      <div className="card-head">
        <h3>{title}</h3>
        {hint && <span>{hint}</span>}
      </div>
      <div className="chart-box">{children}</div>
    </section>
  );
}
