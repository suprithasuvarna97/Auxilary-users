import { useEffect, useState } from "react";
import { DatabaseZap } from "lucide-react";
import { dataMode } from "./api.js";
import Sidebar from "./components/Sidebar.jsx";
import Overview from "./pages/Overview.jsx";
import AuxAnalysis from "./pages/AuxAnalysis.jsx";
import Agents from "./pages/Agents.jsx";
import Deviations from "./pages/Deviations.jsx";
import LiveMonitor from "./pages/LiveMonitor.jsx";

const PAGES = {
  overview: { title: "Overview", sub: "Where logged-in time is going across the floor", Page: Overview },
  analysis: { title: "Aux analysis", sub: "ACW, PER and CBK against their daily norms", Page: AuxAnalysis },
  agents: { title: "Agents", sub: "Who is leaking time, and how much", Page: Agents },
  deviations: { title: "Deviation report", sub: "Calculated deviations with plain-language explanations", Page: Deviations },
  live: { title: "Live monitor", sub: "Current auxiliary state of every agent", Page: LiveMonitor },
};

export default function App() {
  const [page, setPage] = useState("overview");
  const [days, setDays] = useState(14);
  const { title, sub, Page } = PAGES[page];
  const [isMock, setIsMock] = useState(dataMode.isMock());
  const [reload, setReload] = useState(0);

  useEffect(() => dataMode.subscribe(setIsMock), []);

  function retry() {
    dataMode.retryBackend();
    setIsMock(dataMode.isMock());
    setReload((x) => x + 1); // remount the page so it fetches again
  }

  return (
    <div className="app">
      <Sidebar page={page} onChange={setPage} />
      <main className="main">
        <header className="topbar">
          <div>
            <h1>{title}</h1>
            <p>{sub}</p>
          </div>
          {page !== "live" && (
            <label className="range">
              Period
              <select value={days} onChange={(e) => setDays(+e.target.value)}>
                <option value={7}>Last 7 days</option>
                <option value={14}>Last 14 days</option>
                <option value={30}>Last 30 days</option>
              </select>
            </label>
          )}
        </header>
        <div className="content">
          {isMock && (
            <div className="mock-banner">
              <DatabaseZap size={16} />
              <span>
                {dataMode.isForced()
                  ? "Showing built-in dummy data (VITE_USE_MOCK=true)."
                  : "Backend not reachable, so you are seeing built-in dummy data."}
              </span>
              {!dataMode.isForced() && <button onClick={retry}>Retry live API</button>}
            </div>
          )}
          <Page key={reload} days={days} />
        </div>
      </main>
    </div>
  );
}
