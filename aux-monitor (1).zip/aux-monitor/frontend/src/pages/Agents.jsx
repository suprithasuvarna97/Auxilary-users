import { useState } from "react";
import { Search } from "lucide-react";
import useApi from "../hooks/useApi.js";
import { api, hrs } from "../api.js";
import Status from "../components/Status.jsx";

function Bar({ value, tone }) {
  return (
    <div className="bar">
      <div className={`bar-fill ${tone}`} style={{ width: `${Math.min(100, value)}%` }} />
      <span>{value}%</span>
    </div>
  );
}

const riskLabel = (r) => (r >= 90 ? "Critical" : r >= 60 ? "High" : r >= 30 ? "Medium" : "Low");

export default function Agents({ days }) {
  const [q, setQ] = useState("");
  const { data, loading, error } = useApi(() => api.users(days), [days]);
  if (!data) return <Status loading={loading} error={error} />;
  const rows = data.filter((u) => u.user_name.toLowerCase().includes(q.toLowerCase()));

  return (
    <section className="card">
      <div className="card-head">
        <h3>Agent leaderboard</h3>
        <label className="search">
          <Search size={14} />
          <input placeholder="Search agent" value={q} onChange={(e) => setQ(e.target.value)} />
        </label>
      </div>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Agent</th><th>Avg login</th><th>ACW</th><th>PER</th><th>CBK</th>
              <th>Compliance</th><th>Utilization</th><th>Leakage</th><th>High-risk days</th><th>Risk</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((u) => {
              const sev = riskLabel(u.avg_risk);
              return (
                <tr key={u.user_name}>
                  <td className="strong">{u.user_name}</td>
                  <td>{hrs(u.avg_working_min)}</td>
                  <td>{Math.round(u.avg_acw)}m</td>
                  <td className={u.avg_per > 45 ? "over" : ""}>{Math.round(u.avg_per)}m</td>
                  <td>{Math.round(u.avg_cbk)}m</td>
                  <td><Bar value={Math.min(100, u.compliance)} tone="teal" /></td>
                  <td><Bar value={u.utilization} tone="indigo" /></td>
                  <td>{hrs(u.leakage_min)}</td>
                  <td>{u.high_risk_days}</td>
                  <td><span className={`badge sev-${sev}`}>{sev}</span></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}
