import { useState } from "react";
import { Sparkles } from "lucide-react";
import useApi from "../hooks/useApi.js";
import { api } from "../api.js";
import Status from "../components/Status.jsx";

export default function Deviations({ days }) {
  const [severity, setSeverity] = useState("All");
  const [user, setUser] = useState("All");
  const [refresh, setRefresh] = useState(0);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState("");

  const { data, loading, error } = useApi(
    () => Promise.all([api.deviations(days, severity, user), api.users(days), api.config()]),
    [days, severity, user, refresh]
  );

  async function regenerate() {
    setBusy(true);
    setNote("");
    try {
      const r = await api.process(true);
      setNote(
        r.llm_rows > 0
          ? `${r.llm_rows} riskiest rows explained by the LLM.`
          : r.is_llm
          ? "The LLM did not return text (check ANTHROPIC_API_KEY), so rule-based explanations were used."
          : "LLM is off (IS_LLM=false), so dummy rule-based explanations were used."
      );
      setRefresh((x) => x + 1);
    } catch (e) {
      setNote(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="card">
      <div className="card-head wrap">
        <h3>Deviation report</h3>
        <div className="filters">
          <select value={severity} onChange={(e) => setSeverity(e.target.value)}>
            {["All", "Critical", "High", "Medium", "Low"].map((s) => <option key={s}>{s}</option>)}
          </select>
          <select value={user} onChange={(e) => setUser(e.target.value)}>
            <option>All</option>
            {data && data[1].map((u) => <option key={u.user_name}>{u.user_name}</option>)}
          </select>
          <button className="btn" onClick={regenerate} disabled={busy}>
            <Sparkles size={15} />
            {busy ? "Working…" : data && data[2].is_llm ? "Generate AI explanations" : "Rebuild explanations (LLM off)"}
          </button>
        </div>
      </div>
      {note && <p className="note">{note}</p>}
      {!data ? (
        <Status loading={loading} error={error} />
      ) : (
        <div className="table-wrap tall">
          <table>
            <thead>
              <tr>
                <th>Date</th><th>Agent</th><th>Short of target</th><th>ACW over</th><th>PER over</th>
                <th>CBK over</th><th>Leakage</th><th>Severity</th><th className="wide">Explanation</th>
              </tr>
            </thead>
            <tbody>
              {data[0].map((r) => (
                <tr key={r.id}>
                  <td>{r.work_date}</td>
                  <td className="strong">{r.user_name}</td>
                  <td>{r.shortfall_min}m</td>
                  <td>{r.acw_excess_min}m</td>
                  <td className={r.per_excess_min > 0 ? "over" : ""}>{r.per_excess_min}m</td>
                  <td>{r.cbk_excess_min}m</td>
                  <td className="strong">{r.total_excess_min}m</td>
                  <td><span className={`badge sev-${r.severity}`}>{r.severity}</span></td>
                  <td className="wide explain">
                    {r.llm_explanation}
                    <small>{r.explanation_source === "llm" ? "Written by LLM" : "Rule-based"}</small>
                  </td>
                </tr>
              ))}
              {data[0].length === 0 && <tr><td colSpan={9} className="empty">No rows match these filters.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
