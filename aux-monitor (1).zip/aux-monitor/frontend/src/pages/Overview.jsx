import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart,
  Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { AlertOctagon, Clock, Coffee, Gauge, Hourglass, ShieldCheck, TimerOff, Users } from "lucide-react";
import useApi from "../hooks/useApi.js";
import { api, hrs, toHours } from "../api.js";
import KpiCard from "../components/KpiCard.jsx";
import ChartCard from "../components/ChartCard.jsx";
import Status from "../components/Status.jsx";
import { axisProps, COLORS, SEVERITY_COLORS, tooltipStyle } from "../components/chartTheme.js";

export default function Overview({ days }) {
  const { data, loading, error } = useApi(
    () => Promise.all([api.kpis(days), api.trend(days), api.breakdown(days), api.users(days), api.severity(days)]),
    [days]
  );
  if (!data) return <Status loading={loading} error={error} />;
  const [k, trend, bd, users, sev] = data;

  const trendData = trend.map((r) => ({
    date: r.date.slice(5),
    "Avg logged-in (h)": toHours(r.avg_working_min),
    "Target (h)": toHours(r.threshold_min),
    "Leakage (min)": r.avg_leakage_min,
  }));
  const mix = [
    { name: "Productive", value: toHours(bd.productive), color: COLORS.productive },
    { name: "ACW", value: toHours(bd.acw), color: COLORS.acw },
    { name: "PER", value: toHours(bd.per), color: COLORS.per },
    { name: "CBK", value: toHours(bd.cbk), color: COLORS.cbk },
  ];
  const top = users.slice(0, 8).map((u) => ({ name: u.user_name.split(" ")[0], "Leakage (h)": toHours(u.leakage_min) }));

  return (
    <>
      <div className="kpi-grid">
        <KpiCard icon={Users} label="Agents monitored" value={k.agents} sub={`${days}-day window`} />
        <KpiCard icon={Clock} label="Avg logged-in time" value={hrs(k.avg_working_min)} sub="Target 9h 00m" tone="indigo" />
        <KpiCard icon={ShieldCheck} label="Threshold compliance" value={k.avg_compliance} unit="%" sub="Logged-in vs 9h target" />
        <KpiCard icon={Gauge} label="Utilization" value={k.avg_utilization} unit="%" sub="Productive share of login" tone="indigo" />
        <KpiCard icon={TimerOff} label="Time leakage" value={toHours(k.leakage_min)} unit="h" sub="Above ACW / PER / CBK norms" tone="coral" />
        <KpiCard icon={Coffee} label="Break overrun (PER)" value={toHours(k.per_excess_min)} unit="h" sub="Personal time beyond 45 min/day" tone="coral" />
        <KpiCard icon={Hourglass} label="Unused capacity" value={toHours(k.shortfall_min)} unit="h" sub="Short of the 9h target" tone="amber" />
        <KpiCard icon={AlertOctagon} label="High-risk agent-days" value={k.high_risk_cases} sub="High or Critical severity" tone="coral" />
      </div>

      <div className="grid g-2-1">
        <ChartCard title="Logged-in time vs target" hint="Daily average per agent">
          <ResponsiveContainer>
            <LineChart data={trendData} margin={{ left: -10, right: 8 }}>
              <CartesianGrid stroke={COLORS.grid} vertical={false} />
              <XAxis dataKey="date" {...axisProps} />
              <YAxis domain={[6, 10]} {...axisProps} />
              <Tooltip {...tooltipStyle} />
              <Legend iconType="plainline" wrapperStyle={{ fontSize: 12 }} />
              <Line type="monotone" dataKey="Avg logged-in (h)" stroke={COLORS.productive} strokeWidth={2.5} dot={false} />
              <Line type="monotone" dataKey="Target (h)" stroke={COLORS.ink} strokeDasharray="5 4" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
        <ChartCard title="Where logged-in hours went" hint="Total hours, all agents">
          <ResponsiveContainer>
            <PieChart>
              <Pie data={mix} dataKey="value" nameKey="name" innerRadius={62} outerRadius={95} paddingAngle={2}>
                {mix.map((m) => <Cell key={m.name} fill={m.color} />)}
              </Pie>
              <Tooltip {...tooltipStyle} formatter={(v) => `${v} h`} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="grid g-1-1">
        <ChartCard title="Agents losing the most time" hint="Hours above norms, top 8">
          <ResponsiveContainer>
            <BarChart data={top} margin={{ left: -10 }}>
              <CartesianGrid stroke={COLORS.grid} vertical={false} />
              <XAxis dataKey="name" {...axisProps} />
              <YAxis {...axisProps} />
              <Tooltip {...tooltipStyle} />
              <Bar dataKey="Leakage (h)" fill={COLORS.per} radius={[5, 5, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
        <ChartCard title="Daily leakage and severity mix" hint="Avg minutes lost per agent per day">
          <div className="split">
            <ResponsiveContainer width="62%">
              <AreaChart data={trendData} margin={{ left: -20 }}>
                <CartesianGrid stroke={COLORS.grid} vertical={false} />
                <XAxis dataKey="date" {...axisProps} />
                <YAxis {...axisProps} />
                <Tooltip {...tooltipStyle} />
                <Area type="monotone" dataKey="Leakage (min)" stroke={COLORS.per} fill={COLORS.per} fillOpacity={0.18} strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
            <ResponsiveContainer width="38%">
              <PieChart>
                <Pie data={sev} dataKey="count" nameKey="severity" outerRadius={70}>
                  {sev.map((s) => <Cell key={s.severity} fill={SEVERITY_COLORS[s.severity]} />)}
                </Pie>
                <Tooltip {...tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>
      </div>
    </>
  );
}
