import { useEffect, useState } from "react";
import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { AlertTriangle } from "lucide-react";
import { api } from "../api.js";
import ChartCard from "../components/ChartCard.jsx";
import Status from "../components/Status.jsx";
import { axisProps, COLORS, tooltipStyle } from "../components/chartTheme.js";

const STATE_COLOR = {
  "On Call": COLORS.productive, Available: "#5FA8A0", ACW: COLORS.acw, PER: COLORS.per, CBK: COLORS.cbk,
};
const mmss = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

export default function LiveMonitor() {
  const [feed, setFeed] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    let alive = true;
    const tick = () =>
      api.live().then((d) => alive && (setFeed(d), setError(null))).catch((e) => alive && setError(e.message));
    tick();
    const id = setInterval(tick, 5000);
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, []);

  if (!feed) return <Status loading={!error} error={error} />;

  const counts = Object.keys(STATE_COLOR).map((s) => ({
    state: s, agents: feed.agents.filter((a) => a.state === s).length,
  }));
  const alerts = feed.agents.filter((a) => a.alert);

  return (
    <>
      {alerts.length > 0 && (
        <div className="alert-banner">
          <AlertTriangle size={16} />
          {alerts.map((a) => `${a.user_name} (${mmss(a.seconds)} in PER)`).join(" · ")} — over the {feed.per_alert_sec}s break alert limit
        </div>
      )}
      <div className="grid g-2-1">
        <section className="card">
          <div className="card-head"><h3>Agents right now</h3><span>Refreshes every 5 seconds</span></div>
          <div className="live-grid">
            {feed.agents.map((a) => (
              <div key={a.user_name} className={a.alert ? "live-card alert" : "live-card"}>
                <span className="dot" style={{ background: STATE_COLOR[a.state] }} />
                <div>
                  <b>{a.user_name}</b>
                  <small>{a.state} · {mmss(a.seconds)}</small>
                </div>
              </div>
            ))}
          </div>
        </section>
        <ChartCard title="Agents by state" hint="Live count">
          <ResponsiveContainer>
            <BarChart data={counts} layout="vertical" margin={{ left: 10 }}>
              <XAxis type="number" allowDecimals={false} {...axisProps} />
              <YAxis type="category" dataKey="state" width={64} {...axisProps} />
              <Tooltip {...tooltipStyle} />
              <Bar dataKey="agents" radius={[0, 5, 5, 0]}>
                {counts.map((c) => <Cell key={c.state} fill={STATE_COLOR[c.state]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </>
  );
}
