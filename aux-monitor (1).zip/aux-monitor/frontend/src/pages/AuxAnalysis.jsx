import {
  Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ReferenceLine,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import useApi from "../hooks/useApi.js";
import { api, toHours } from "../api.js";
import ChartCard from "../components/ChartCard.jsx";
import Status from "../components/Status.jsx";
import { axisProps, COLORS, tooltipStyle } from "../components/chartTheme.js";

const avg = (arr, key) => (arr.length ? arr.reduce((s, r) => s + r[key], 0) / arr.length : 0);

export default function AuxAnalysis({ days }) {
  const { data, loading, error } = useApi(
    () => Promise.all([api.config(), api.trend(days), api.users(days)]),
    [days]
  );
  if (!data) return <Status loading={loading} error={error} />;
  const [cfg, trend, users] = data;
  const n = cfg.norms;

  const actualVsNorm = [
    { state: "ACW", Actual: +avg(users, "avg_acw").toFixed(1), Norm: n.acw },
    { state: "PER", Actual: +avg(users, "avg_per").toFixed(1), Norm: n.per },
    { state: "CBK", Actual: +avg(users, "avg_cbk").toFixed(1), Norm: n.cbk },
  ];
  const byAgent = users.map((u) => ({
    name: u.user_name.split(" ")[0], ACW: Math.round(u.avg_acw), PER: Math.round(u.avg_per), CBK: Math.round(u.avg_cbk),
  }));
  const excess = users.map((u) => ({
    name: u.user_name.split(" ")[0], "ACW over": toHours(u.acw_excess), "PER over": toHours(u.per_excess), "CBK over": toHours(u.cbk_excess),
  }));
  const daily = trend.map((r) => ({ date: r.date.slice(5), ACW: r.avg_acw, PER: r.avg_per, CBK: r.avg_cbk }));

  return (
    <>
      <div className="grid g-1-1">
        <ChartCard title="Average daily minutes vs norm" hint="All agents">
          <ResponsiveContainer>
            <BarChart data={actualVsNorm} margin={{ left: -10 }}>
              <CartesianGrid stroke={COLORS.grid} vertical={false} />
              <XAxis dataKey="state" {...axisProps} />
              <YAxis {...axisProps} />
              <Tooltip {...tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="Actual" fill={COLORS.per} radius={[5, 5, 0, 0]} />
              <Bar dataKey="Norm" fill={COLORS.ink} radius={[5, 5, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
        <ChartCard title="Daily trend per aux state" hint="Dashed line = PER norm">
          <ResponsiveContainer>
            <LineChart data={daily} margin={{ left: -10 }}>
              <CartesianGrid stroke={COLORS.grid} vertical={false} />
              <XAxis dataKey="date" {...axisProps} />
              <YAxis {...axisProps} />
              <Tooltip {...tooltipStyle} />
              <Legend iconType="plainline" wrapperStyle={{ fontSize: 12 }} />
              <ReferenceLine y={n.per} stroke={COLORS.per} strokeDasharray="4 4" />
              <Line dataKey="ACW" stroke={COLORS.acw} strokeWidth={2} dot={false} />
              <Line dataKey="PER" stroke={COLORS.per} strokeWidth={2.5} dot={false} />
              <Line dataKey="CBK" stroke={COLORS.cbk} strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
      <div className="grid g-1-1">
        <ChartCard title="Aux minutes per agent per day" hint="Stacked average">
          <ResponsiveContainer>
            <BarChart data={byAgent} margin={{ left: -10 }}>
              <CartesianGrid stroke={COLORS.grid} vertical={false} />
              <XAxis dataKey="name" {...axisProps} interval={0} />
              <YAxis {...axisProps} />
              <Tooltip {...tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="ACW" stackId="a" fill={COLORS.acw} />
              <Bar dataKey="PER" stackId="a" fill={COLORS.per} />
              <Bar dataKey="CBK" stackId="a" fill={COLORS.cbk} radius={[5, 5, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
        <ChartCard title="Hours over norm, by state" hint="Where each agent's leakage comes from">
          <ResponsiveContainer>
            <BarChart data={excess} margin={{ left: -10 }}>
              <CartesianGrid stroke={COLORS.grid} vertical={false} />
              <XAxis dataKey="name" {...axisProps} interval={0} />
              <YAxis {...axisProps} />
              <Tooltip {...tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="ACW over" stackId="e" fill={COLORS.acw} />
              <Bar dataKey="PER over" stackId="e" fill={COLORS.per} />
              <Bar dataKey="CBK over" stackId="e" fill={COLORS.cbk} radius={[5, 5, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </>
  );
}
