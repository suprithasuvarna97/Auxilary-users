import { mock } from "./mockData.js";

const BASE = import.meta.env.VITE_API_URL || "/api";
const FORCE_MOCK = import.meta.env.VITE_USE_MOCK === "true";
const FALLBACK = import.meta.env.VITE_MOCK_FALLBACK !== "false";

// ---- data mode: "live" API or built-in dummy data ----
let usingMock = FORCE_MOCK;
const listeners = new Set();
export const dataMode = {
  isMock: () => usingMock,
  isForced: () => FORCE_MOCK,
  subscribe(fn) {
    listeners.add(fn);
    return () => listeners.delete(fn);
  },
  retryBackend() {
    if (!FORCE_MOCK) setMock(false);
  },
};
function setMock(v) {
  if (usingMock !== v) {
    usingMock = v;
    listeners.forEach((fn) => fn(v));
  }
}

async function call(name, path, args, options) {
  if (usingMock) return mock[name](...args);
  try {
    const res = await fetch(BASE + path, options);
    if (!res.ok) throw new Error(`Request failed (${res.status}) for ${path}`);
    return await res.json();
  } catch (err) {
    if (!FALLBACK) throw err;
    setMock(true); // backend is down -> switch to dummy data
    return mock[name](...args);
  }
}

export const api = {
  config: () => call("config", "/config", []),
  kpis: (days) => call("kpis", `/kpis?days=${days}`, [days]),
  trend: (days) => call("trend", `/trend?days=${days}`, [days]),
  breakdown: (days) => call("breakdown", `/breakdown?days=${days}`, [days]),
  severity: (days) => call("severity", `/severity?days=${days}`, [days]),
  users: (days) => call("users", `/users?days=${days}`, [days]),
  deviations: (days, severity = "All", user = "All") =>
    call("deviations", `/deviations?days=${days}&severity=${encodeURIComponent(severity)}&user=${encodeURIComponent(user)}`, [days, severity, user]),
  process: (useLlm = true) => call("process", `/process?use_llm=${useLlm}`, [useLlm], { method: "POST" }),
  live: () => call("live", "/live", []),
};

export const hrs = (min) => `${Math.floor(min / 60)}h ${String(Math.round(min % 60)).padStart(2, "0")}m`;
export const toHours = (min) => +(min / 60).toFixed(2);
