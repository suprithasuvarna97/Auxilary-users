// Client-side dummy data. Mirrors the backend maths so every page works without the API.
const NORMS = { acw: 60, per: 45, cbk: 30 };
const THRESHOLD = 540;
const USERS = [
  ["Aarav Sharma", "good"], ["Priya Nair", "good"], ["Rohan Mehta", "average"], ["Sneha Iyer", "average"],
  ["Karthik Reddy", "breaker"], ["Ananya Das", "average"], ["Vikram Singh", "breaker"], ["Meera Joshi", "acw_heavy"],
  ["Rahul Verma", "good"], ["Divya Menon", "erratic"], ["Arjun Patel", "acw_heavy"], ["Neha Gupta", "average"],
];
const PROFILES = {
  good: [0, 50, 35, 22], average: [-20, 62, 50, 30], breaker: [-45, 70, 95, 35],
  acw_heavy: [-25, 115, 45, 28], erratic: [-30, 75, 70, 40],
};

function rng(seed) {
  return () => {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const gauss = (r, mean, sd) => mean + sd * Math.sqrt(-2 * Math.log(1 - r())) * Math.cos(2 * Math.PI * r());
const iso = (d) => d.toISOString().slice(0, 10);
const fmt = (m) => `${Math.floor(m / 60)}h ${String(Math.round(m % 60)).padStart(2, "0")}m`;
const sum = (a, k) => a.reduce((s, r) => s + r[k], 0);
const avg = (a, k) => (a.length ? sum(a, k) / a.length : 0);
const r1 = (x, d = 1) => +x.toFixed(d);

function explain(r) {
  const s1 = r.shortfall_min > 0
    ? `${r.user_name} was logged in for ${fmt(r.working_time_min)} against a ${fmt(THRESHOLD)} target, leaving ${r.shortfall_min} min of paid capacity unused.`
    : `${r.user_name} met the ${fmt(THRESHOLD)} login target.`;
  const d = [];
  if (r.per_excess_min) d.push(`personal/break time was ${r.per_min} min vs a ${NORMS.per} min norm (+${r.per_excess_min})`);
  if (r.acw_excess_min) d.push(`after-call work was ${r.acw_min} min vs ${NORMS.acw} (+${r.acw_excess_min})`);
  if (r.cbk_excess_min) d.push(`callback time was ${r.cbk_min} min vs ${NORMS.cbk} (+${r.cbk_excess_min})`);
  const s2 = d.length ? `Time leaked mainly because ${d.join("; ")}.` : "All auxiliary states stayed inside their norms.";
  const act = {
    Critical: "Recommend an immediate coaching conversation and a review of break scheduling.",
    High: "Recommend a team-lead check-in this week.",
    Medium: "Keep monitoring; a gentle reminder on break discipline may be enough.",
    Low: "No action needed.",
  }[r.severity];
  return `${s1} ${s2} ${act}`;
}

let ROWS = null;
function rows() {
  if (ROWS) return ROWS;
  const r = rng(42);
  ROWS = [];
  let id = 1;
  for (let off = 30; off >= 1; off--) {
    const day = new Date(); day.setDate(day.getDate() - off);
    if ([0, 6].includes(day.getDay())) continue;
    for (const [name, p] of USERS) {
      const [shift, acw0, per0, cbk0] = PROFILES[p];
      const sd = p === "erratic" ? 2 : 1;
      const working = Math.max(300, Math.min(600, Math.round(gauss(r, THRESHOLD + shift, 25 * sd))));
      const acw = Math.max(5, Math.round(gauss(r, acw0, 14 * sd)));
      const per = Math.max(5, Math.round(gauss(r, per0, 14 * sd)));
      const cbk = Math.max(2, Math.round(gauss(r, cbk0, 8 * sd)));
      const ax = Math.max(0, acw - NORMS.acw), px = Math.max(0, per - NORMS.per), cx = Math.max(0, cbk - NORMS.cbk);
      const total = ax + px + cx;
      const shortfall = Math.max(0, THRESHOLD - working);
      const productive = Math.max(0, working - acw - per - cbk);
      const risk = r1(total + 0.5 * shortfall);
      const row = {
        id: id++, user_name: name, work_date: iso(day), working_time_min: working, threshold_min: THRESHOLD,
        acw_min: acw, per_min: per, cbk_min: cbk, acw_excess_min: ax, per_excess_min: px, cbk_excess_min: cx,
        total_excess_min: total, shortfall_min: shortfall, productive_min: productive,
        utilization_pct: r1((productive / working) * 100), compliance_pct: r1((working / THRESHOLD) * 100), risk_score: risk,
        severity: risk >= 90 ? "Critical" : risk >= 60 ? "High" : risk >= 30 ? "Medium" : "Low",
        explanation_source: "rules", created_at: null,
      };
      row.llm_explanation = explain(row);
      ROWS.push(row);
    }
  }
  return ROWS;
}

const windowRows = (days) => {
  const d = new Date(); d.setDate(d.getDate() - days);
  const cut = iso(d);
  return rows().filter((x) => x.work_date >= cut);
};
const group = (list, key) => list.reduce((m, r) => ((m[r[key]] ||= []).push(r), m), {});
const wait = (v) => new Promise((res) => setTimeout(() => res(v), 120)); // feels like a real call

export const mock = {
  config: () => wait({ norms: NORMS, threshold_min: THRESHOLD, is_llm: false, mock: true }),
  kpis: (days) => {
    const w = windowRows(days);
    return wait({
      agents: new Set(w.map((r) => r.user_name)).size, avg_working_min: r1(avg(w, "working_time_min")),
      avg_compliance: r1(avg(w, "compliance_pct")), leakage_min: sum(w, "total_excess_min"),
      per_excess_min: sum(w, "per_excess_min"), avg_utilization: r1(avg(w, "utilization_pct")),
      shortfall_min: sum(w, "shortfall_min"), high_risk_cases: w.filter((r) => ["High", "Critical"].includes(r.severity)).length,
    });
  },
  trend: (days) =>
    wait(Object.entries(group(windowRows(days), "work_date")).sort().map(([date, g]) => ({
      date, avg_working_min: r1(avg(g, "working_time_min")), threshold_min: THRESHOLD, avg_leakage_min: r1(avg(g, "total_excess_min")),
      avg_acw: r1(avg(g, "acw_min")), avg_per: r1(avg(g, "per_min")), avg_cbk: r1(avg(g, "cbk_min")),
    }))),
  breakdown: (days) => {
    const w = windowRows(days);
    return wait({ productive: sum(w, "productive_min"), acw: sum(w, "acw_min"), per: sum(w, "per_min"), cbk: sum(w, "cbk_min") });
  },
  severity: (days) =>
    wait(Object.entries(group(windowRows(days), "severity")).map(([severity, g]) => ({ severity, count: g.length }))),
  users: (days) =>
    wait(Object.entries(group(windowRows(days), "user_name")).map(([user_name, g]) => ({
      user_name, avg_working_min: r1(avg(g, "working_time_min")), avg_acw: r1(avg(g, "acw_min")), avg_per: r1(avg(g, "per_min")),
      avg_cbk: r1(avg(g, "cbk_min")), leakage_min: sum(g, "total_excess_min"), compliance: r1(avg(g, "compliance_pct")),
      utilization: r1(avg(g, "utilization_pct")), avg_risk: r1(avg(g, "risk_score")),
      high_risk_days: g.filter((r) => ["High", "Critical"].includes(r.severity)).length,
      acw_excess: sum(g, "acw_excess_min"), per_excess: sum(g, "per_excess_min"), cbk_excess: sum(g, "cbk_excess_min"),
    })).sort((a, b) => b.leakage_min - a.leakage_min)),
  deviations: (days, severity = "All", user = "All") =>
    wait(windowRows(days)
      .filter((r) => (severity === "All" || r.severity === severity) && (user === "All" || r.user_name === user))
      .sort((a, b) => b.risk_score - a.risk_score || b.work_date.localeCompare(a.work_date))
      .slice(0, 300)),
  process: () => wait({ rows: rows().length, llm_rows: 0, is_llm: false }),
  live: () => {
    const states = ["On Call", "Available", "ACW", "PER", "CBK"], weights = [40, 25, 15, 12, 8];
    const now = Date.now() / 1000;
    mock._live ||= {};
    const agents = USERS.map(([name]) => {
      let cur = mock._live[name];
      const p = cur && cur.state === "PER" ? 0.04 : 0.15;
      if (!cur || Math.random() < p) {
        let x = Math.random() * 100, i = 0;
        while (x > weights[i]) x -= weights[i++];
        cur = mock._live[name] = { state: states[i], since: now };
      }
      const seconds = Math.floor(now - cur.since);
      return { user_name: name, state: cur.state, seconds, alert: cur.state === "PER" && seconds >= 60 };
    });
    return wait({ timestamp: now, per_alert_sec: 60, agents });
  },
};
