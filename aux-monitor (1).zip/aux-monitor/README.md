# AUX Monitor

React (JSX) + FastAPI + PostgreSQL dashboard for auxiliary-state (ACW / PER / CBK) deviation monitoring.

## 1. Backend
```
cd backend
python -m venv venv && source venv/bin/activate     # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env        # set DATABASE_URL (+ ANTHROPIC_API_KEY for real LLM text)
uvicorn main:app --reload --port 8000
```
On first start it creates the database, the `aux_activity` and `aux_deviation_output` tables,
seeds ~30 days of dummy data for 12 agents and calculates the deviations.

## 2. Frontend
```
cd frontend
npm install
npm run dev        # http://localhost:5173  (proxies /api to :8000)
```

## Dummy data / LLM switch
- `backend/.env` -> `IS_LLM=false` : never calls an LLM; the explanation column uses dummy rule-based text. Set `true` (+ `ANTHROPIC_API_KEY`) to use the LLM.
- Backend not running? The UI automatically falls back to built-in dummy data and shows a banner. Force it with `VITE_USE_MOCK=true` in `frontend/.env`, or disable the fallback with `VITE_MOCK_FALLBACK=false`.
